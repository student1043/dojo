@if(theme('ad_sidebar'))
	{!! theme('ad_sidebar') !!}
@else
	<a href="http://codecanyon.net/item/ninja-media-script-viral-fun-media-sharing-site/6822888" target="_blank">
		<img src="{{ theme_folder_url('/assets/img/advertisement.jpg') }}" width="302" height="252">
	</a>
@endif