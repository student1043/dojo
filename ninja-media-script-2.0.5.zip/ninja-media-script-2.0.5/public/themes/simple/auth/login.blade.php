@extends('theme::app')

@section('content')

<div id="wrap" class="auth">

	@include('theme::includes.form-login')

</div>

@stop