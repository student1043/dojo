<div id="wrap">
	<h3 style="text-align:center;">Sorry, it looks like this page doesn't exist...</h3>
	<a href="<?= URL::to('/'); ?>" style="text-align:center; width:100%; display:block;">Click here to return home</a>
</div>
